# gallery2

This is a fork of the now-dormant [gallery2](http://galleryproject.org/) project.  The gallery code was written against PHP 5, and there are some changes in PHP 7 that were causing problems for me (as well as a bunch of warnings).  I fixed the two bugs I found and cleaned up some of the warnings.

This code is based on gallery2 version 2.3.2 (core version 1.3.0.2)
