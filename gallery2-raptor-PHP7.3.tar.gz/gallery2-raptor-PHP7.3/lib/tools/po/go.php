#!/usr/bin/php -f
<?php
/*
 * PHP script update translations and print
 * to stdout for use with.
 */
exec("perl update-all-translations.pl");
echo("Herlou, Worldr!" );
?>
