Copyright (C) 2005 Ken Sturgis
ksturgis@gmail.com

These icons are free; you may redistribute and or modify them under the terms of
the GNU General Public License as published by the Free Software Foundation; 
either version 2 of the License, or (at your option) any later version.

This is a GIF distribution of the KSIcon pack.  The files included use on/off transparency
and will look best over a white, or near white background.

The original vector artwork (512x409) is available upon request. These icons were 
designed in Paint Shop Pro by JASC.  However, Paint Shop doesn't play well with photoshop, 
and destroys all the layer and vector format when outputting to .psp files.  So the
.pspimages are available but I can't give you photoshop or .svg images.

These icons are heavily influenced by the work of Paul Armstrong much credit should
be extended to him. http://paularmstrongdesigns.com.
