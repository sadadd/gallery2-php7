function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_setTextOfTextfield(objName,x,newText) { //v3.0
  var obj = MM_findObj(objName); if (obj) obj.value = newText;
}

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') {
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (val<min || max<val) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}

function x() { return; }

function _insertEmoticon(addSmilie) {
    document.getElementById('msg').value += ' ' +addSmilie+' ';
    document.getElementById('msg').focus();
}

function setSelRange(selStart, selEnd) {
  var inputEl = document.getElementById('msg');

  if (inputEl.setSelectionRange) {
    inputEl.focus();
    inputEl.setSelectionRange(selStart, selEnd);
  } else if (inputEl.createTextRange) {
    var range = inputEl.createTextRange();
    range.collapse(true);
    range.moveEnd('character', selEnd);
    range.moveStart('character', selStart);
    range.select();
  }
}

function insertEmoticon(smilieface){
  var t = document.getElementById('msg');
  if (t.createTextRange && t.caretPos){
    var caretPos = t.caretPos;
    caretPos.text = smilieface;
    t.focus();
  } else {
    t.value+=smilieface;
    t.focus();
  }
}

function del() {
    input_box=confirm("Are you sure you want to delete the selected messages?");
    if (input_box==true) { // redirect when OK is clicked
    return true;
    } else {
    // Output when Cancel is clicked
    return false;
    }
}

function storeCaret(ftext){
  if (ftext.createTextRange){
    ftext.caretPos = document.selection.createRange().duplicate();
  }
}